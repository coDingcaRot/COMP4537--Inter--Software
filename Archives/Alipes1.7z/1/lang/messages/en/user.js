// Titles
const readerTitle = "Reader Page";
const writerTitle = "Writer Page";
const landingTitle = "landing Page";

//A texts
const backButtonText = "landing page";
const writerLink = "Writer";
const readerLink = "reader";

//button text
const addBtn = "Add";
const backBtn = "Back";