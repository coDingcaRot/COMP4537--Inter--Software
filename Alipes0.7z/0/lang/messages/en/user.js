//prompt message
let displayMessage = "How many buttons to create?"

//input check message
let confrimationInvalid = "The number inputed is invalid please enter a number between 3 - 7"

//Game messages
let gameWinMsg = "Excellent Memory!"
let gameFailMsg = "Wrong Order!"